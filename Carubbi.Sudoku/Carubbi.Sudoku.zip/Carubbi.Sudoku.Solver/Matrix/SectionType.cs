﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Carubbi.Sudoku.Solver
{
    public enum SectionType : int
	{
	    Row,
        Column,
        Quadrant
	}  
   
}
